// Configuration for Groq API
export const CONFIG = {
  API_KEY: process.env.GROQ_API_KEY || "your-api-key-here",
  MODEL_ID: "moonshotai/kimi-k2-instruct-0905"
};