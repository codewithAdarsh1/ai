import GroqClient from './groq-client.js';
import readline from 'readline';

const client = new GroqClient();

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('🤖 AI Chat - Type your questions and press Enter');
console.log('Type "exit" to quit\n');

function askQuestion() {
  rl.question('You: ', async (input) => {
    if (input.toLowerCase() === 'exit') {
      console.log('Goodbye! 👋');
      rl.close();
      return;
    }

    if (input.trim() === '') {
      askQuestion();
      return;
    }

    try {
      console.log('🤖 Thinking...');
      const response = await client.generateText(input);
      console.log(`\nAI: ${response}\n`);
    } catch (error) {
      console.error('❌ Error:', error.message);
    }

    askQuestion();
  });
}

// Start the chat
askQuestion();