import { GoogleGenerativeAI } from '@google/generative-ai';
import { CONFIG } from './config.js';

class GeminiClient {
  constructor() {
    this.genAI = new GoogleGenerativeAI(CONFIG.API_KEY);
    this.model = this.genAI.getGenerativeModel({ model: CONFIG.MODEL_ID });
  }

  async generateText(prompt) {
    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Error generating text:', error);
      throw error;
    }
  }

  async generateTextStream(prompt) {
    try {
      const result = await this.model.generateContentStream(prompt);
      return result.stream;
    } catch (error) {
      console.error('Error generating text stream:', error);
      throw error;
    }
  }

  async chat(messages) {
    try {
      const chat = this.model.startChat({
        history: messages.slice(0, -1).map(msg => ({
          role: msg.role,
          parts: [{ text: msg.content }]
        }))
      });

      const lastMessage = messages[messages.length - 1];
      const result = await chat.sendMessage(lastMessage.content);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Error in chat:', error);
      throw error;
    }
  }
}

export default GeminiClient;