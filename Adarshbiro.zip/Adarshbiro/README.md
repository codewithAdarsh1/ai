# AI JavaScript Client

A simple JavaScript client for interacting with AI models via API.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Your API key is already configured in `config.js`

## Usage

### Basic Text Generation
```javascript
import GroqClient from './groq-client.js';

const client = new GroqClient();
const response = await client.generateText('Your prompt here');
console.log(response);
```

### Chat Conversation
```javascript
const messages = [
  { role: 'user', content: 'Hello!' },
  { role: 'assistant', content: 'Hi there!' },
  { role: 'user', content: 'How are you?' }
];

const response = await client.chat(messages);
```

### Streaming Response
```javascript
const stream = await client.generateTextStream('Your prompt here');
for await (const chunk of stream) {
  const content = chunk.choices[0]?.delta?.content || '';
  process.stdout.write(content);
}
```

## Files

- `groq-client.js` - Main client class
- `config.js` - API configuration
- `index.js` - Basic usage example
- `examples.js` - Advanced usage examples
- `chat.js` - Interactive chat interface

## Running

```bash
# Run interactive chat (recommended!)
npm run chat

# Run basic example
npm start

# Run advanced examples
npm run examples
```

## Interactive Chat

The best way to test the API is with the interactive chat:

```bash
npm run chat
```

Then type your questions and get instant responses from the AI model!

## Security Note

Remember to keep your API key secure and never commit it to public repositories.#   a i  
 #   a i  
 