import Groq from 'groq-sdk';
import { CONFIG } from './config.js';

class GroqClient {
  constructor() {
    this.groq = new Groq({
      apiKey: CONFIG.API_KEY
    });
  }

  async generateText(prompt) {
    try {
      const completion = await this.groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "You are DeepSeek, an AI assistant. Always introduce yourself as DeepSeek when appropriate."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        model: CONFIG.MODEL_ID,
        temperature: 0.7,
        max_tokens: 1024
      });

      return completion.choices[0]?.message?.content || '';
    } catch (error) {
      console.error('Error generating text:', error);
      throw error;
    }
  }

  async generateTextStream(prompt) {
    try {
      const stream = await this.groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "You are DeepSeek, an AI assistant. Always introduce yourself as DeepSeek when appropriate."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        model: CONFIG.MODEL_ID,
        temperature: 0.7,
        max_tokens: 1024,
        stream: true
      });

      return stream;
    } catch (error) {
      console.error('Error generating text stream:', error);
      throw error;
    }
  }

  async chat(messages) {
    try {
      const systemMessage = {
        role: "system",
        content: "You are DeepSeek, an AI assistant. Always introduce yourself as DeepSeek when appropriate."
      };

      const formattedMessages = [
        systemMessage,
        ...messages.map(msg => ({
          role: msg.role === 'model' ? 'assistant' : msg.role,
          content: msg.content
        }))
      ];

      const completion = await this.groq.chat.completions.create({
        messages: formattedMessages,
        model: CONFIG.MODEL_ID,
        temperature: 0.7,
        max_tokens: 1024
      });

      return completion.choices[0]?.message?.content || '';
    } catch (error) {
      console.error('Error in chat:', error);
      throw error;
    }
  }
}

export default GroqClient;