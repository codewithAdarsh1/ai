import GroqClient from './groq-client.js';

const client = new GroqClient();

// Example 1: Simple question
export async function simpleQuestion() {
  const response = await client.generateText('Explain async/await in JavaScript in simple terms.');
  console.log('Simple Question Response:', response);
  return response;
}

// Example 2: Code generation
export async function codeGeneration() {
  const prompt = `
    Write a JavaScript function that:
    1. Takes an array of numbers
    2. Filters out even numbers
    3. Returns the sum of remaining odd numbers
    Please include comments.
  `;
  
  const response = await client.generateText(prompt);
  console.log('Code Generation Response:', response);
  return response;
}

// Example 3: Streaming response
export async function streamingExample() {
  console.log('🌊 Streaming response:');
  const stream = await client.generateTextStream('Write a short story about a JavaScript developer who discovers a magical debugging tool.');
  
  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content || '';
    process.stdout.write(content);
  }
  console.log('\n');
}

// Example 4: Multi-turn conversation
export async function conversationExample() {
  const messages = [
    { role: 'user', content: 'I want to build a todo app in JavaScript' },
    { role: 'assistant', content: 'Great! A todo app is a perfect project. What features do you want to include?' },
    { role: 'user', content: 'I want to add, delete, and mark tasks as complete. Should I use vanilla JS or a framework?' }
  ];

  const response = await client.chat(messages);
  console.log('Conversation Response:', response);
  return response;
}

// Run examples if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('🚀 Running AI API Examples...\n');
  
  try {
    await simpleQuestion();
    console.log('\n' + '='.repeat(50) + '\n');
    
    await codeGeneration();
    console.log('\n' + '='.repeat(50) + '\n');
    
    await streamingExample();
    console.log('\n' + '='.repeat(50) + '\n');
    
    await conversationExample();
    
  } catch (error) {
    console.error('Error running examples:', error.message);
  }
}