import GroqClient from './groq-client.js';

async function main() {
  const client = new GroqClient();

  try {
    // Simple text generation
    console.log('🤖 Testing simple text generation...');
    const response = await client.generateText('Hello! Tell me a fun fact about JavaScript.');
    console.log('Response:', response);
    console.log('\n' + '='.repeat(50) + '\n');

    // Chat conversation
    console.log('💬 Testing chat conversation...');
    const chatMessages = [
      { role: 'user', content: 'Hi, I\'m learning JavaScript. Can you help me?' },
      { role: 'assistant', content: 'Of course! I\'d be happy to help you learn JavaScript. What would you like to know?' },
      { role: 'user', content: 'What are the main differences between let, const, and var?' }
    ];

    const chatResponse = await client.chat(chatMessages);
    console.log('Chat Response:', chatResponse);

  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();